# Statistics and Data Analysis for Financial Engineering 
# Chapter 19: Risk Management

# Example 19.1 VaR with a normally distributed loss
mu <- 0.04
sig <- 0.18
P <- 100000

alpha <- seq(0.0025, 0.25, by = 0.002)
var <- -P * mu + P * sig * qnorm(1 - alpha)

plot(alpha, var, type = "l", 
     xlab = expression(alpha), 
     ylab = expression(paste("VaR(", alpha, ")")))

options(digits = 4)
min(var)
max(var)

# Example 19.2 Nonparameteric VaR and ES for a position in an S&P 500 index fund
data(SP500, package = "Ecdat")
n <- 2783
SPreturn <- SP500$r500[(n-999):n]
year <- 1981 + (1:n)*(1991.25 - 1981) / n
year <- year[(n-999):n]

alpha <- 0.05
q <- as.numeric(quantile(SPreturn, alpha))
VaR_nonp <- -2000 * q
IEVaR <- (SPreturn < q)

sum(IEVaR)
ES_nonp <- -2000 * sum(SPreturn * IEVaR) / sum(IEVaR)

options(digits = 5)
VaR_nonp
ES_nonp

# Example 19.3 Parametric VaR and ES for a position in an S&P 500 index fund 
library(MASS)
data(SP500, package = "Ecdat")
n <- 2783
SPreturn <- SP500$r500[(n-999):n]
year <- 1981 + (1:n) * (1911.25 - 1981) / n
year <- year[(n-999):n]

alpha <- 0.05
fitt <- fitdistr(SPretrun, "t")
param <- as.numeric(fitt$estimate)

mean <- param[1]
df <- param[3]
sd <- param[2] * sqrt(df / (df - 2))
lambda <- param[2]

qalpha <- qt(alpha, df = df)
VaR_par <- -20000 * (mean + lambda * qalpha)
es1 <- dt(alpha, df = df) / alpha
es2 <- (df + qalpha^2) / (df - 1)
es3 <- -mean + lambda * es1 * es2

ES_par <- 20000 * es3
VaR_par
ES_par