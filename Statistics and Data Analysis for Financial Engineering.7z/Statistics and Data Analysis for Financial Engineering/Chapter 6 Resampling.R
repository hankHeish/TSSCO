# Statistical and Data Analysis for Financial Engineering
# Chapter 6: Resampling

# Example 6.1 Bootstrapping GE Daily Returns
library(bootstrap)
library(MASS)

set.seed("3857")
data(CRSPday, package = "Ecdat")
ge <- CRSPday[, 4]
ge_250 <- ge[1:250]
nboot <- 1000
options(digits = 3)

t_mle <- function(x){
    as.vector(fitdistr(x, "t")$estimate)
}

t1 <- proc.time()
results <- bootstrap(ge, nboot, t_mle)
t2 <- proc.time()
t2 - t1

result_250 <- bootstrap(ge_250, nboot, t_mle)
rowMeans(results$thetastar[, ])
apply(results$thetastar[, ], 1, sd)
fitdistr(ge, "t")

apply(result_250$thetastar, 1, mean)
apply(result_250$thetastar, 1, sd)
fitdistr(ge_250, "t")

quantile(result_250$thetastar[3, ], c(0.95, 0.98, 0.99, 0.999))

par(mfrow = c(1, 2))
plot(density(result_250$thetaster[3, ]), xlab = "df", xlim = c(2, 21), main = "(a) n = 250")
plot(density(results$thetaster[3, ]), xlab = "df", xlim = c(2, 21), main = "(a) n = 2528")

