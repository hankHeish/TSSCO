# Statistic and Data Analysis for Financail Engineering
# Chapter 11 Regression: Advanced Topics

# Simulated Bond Price 
bondprice <- read.table("C:/Users/J1060019/Desktop/datasets/bondprices.txt", header = T)
attach(bondprice)

fit <- nls(price ~ 1000*exp(-r*maturity), start = list(r = 0.04))
summary(fit)

par(mfrow = c(1, 1))
plot(maturity, price, pch = "*", cex = 2)
grid <- seq(0, 20, length = 201)
price_grid <- 1000*exp(-0.0585*grid)
lines(grid, price_grid, lwd = 2, col = "red")
detach(bondprice)