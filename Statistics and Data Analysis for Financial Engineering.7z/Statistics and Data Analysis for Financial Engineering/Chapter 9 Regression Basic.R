# Statistical and Data Analysis for Financial Engineering
# Chapter 9 Regression: Basic

# Example 9.1 Weekly Interest Rates - Least-Square estimator

