#Statistics and Data Analysis for Financial Engineering 
#Chapter 18. Factor Models and Principal Components

library(Ecdat)
library(robust)

#Example 18.2 Principal Components analysis of yield curves
DataNoOmit <- read.table("C:/Users/J1060019/Desktop/datasets/treasury_yields.txt", header = T)
diffDataNoOmit <- diff(as.matrix(DataNoOmit[, 2:12]))
Data <- na.omit(DataNoOmit)
diffData <- na.omit(diffDataNoOmit)

n <- dim(diffData)[1]
options(digits = 5)
pca <- prcomp(diffData)
print(summary(pca))

#Example 18.3 Principal Components Analysis of Equity Funds
EquityFund <- read.csv("C:/Users/J1060019/Desktop/datasets/equityFunds.csv", header = T)
pcaEq <- prcomp(EquityFund[, 2:9])
print(summary(pcaEq))

#Example 18.6 Fitting the Fama-French Model to GE, IBM and Mobil
FF_Data <- read.table("C:/Users/J1060019/Desktop/datasets/FamaFrench_mon_69_98.txt", header = T)

GE <- 100 * CRSPmon[, 1] - FF_Data$RF
IBM <- 100 * CRSPmon[, 2] - FF_Data$RF
Mobil <- 100 * CRSPmon[, 3] - FF_Data$RF

stocks <- cbind(GE, IBM, Mobil)
pairs(cbind(stocks, FF_Data$Mkt.RF, FF_Data$SMB, FF_Data$HML), pch = 20, col = "darkgreen")

fitFF <- lm(stocks ~ FF_Data$Mkt.RF + FF_Data$SMB + FF_Data$HML)
print(fitFF)
print(summary(fitFF))
cor(fitFF$residuals)

pairs(stocks, pch = 20, col = "darkred")
covRob(fitFF$residuals, corr = T)

#Example 18.7 Estimating the Covariance Matrix of GE, IBM and Mobil Excess Return
sigF <- as.matrix(var(cbind(FF_Data$Mkt.RF, FF_Data$SMB, FF_Data$HML)))
bBeta <- as.matrix(fitFF$coef)
bBeta <- t(bBeta[-1, ])

n <- dim(CRSPmon)[1]
sigeps <- (n - 1) / (n - 4) * as.matrix(var(as.matrix(fitFF$residuals)))
sigeps <- diag(as.matrix(sigeps))
sigeps <- diag(sigeps, nrow = 3)
Cov_Equity <- bBeta %*% sigF %*% t(bBeta) + sigeps

options(digits = 5)
print(sigF)
print(bBeta)
print(sigeps)
print(Cov_Equity)
print(cov(stocks))

#Example 18.9 Factor Analysis of Equity Funds







